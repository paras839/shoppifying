-- AlterTable
ALTER TABLE "Checkout" ALTER COLUMN "webUrl" DROP NOT NULL;
