-- AlterTable
ALTER TABLE "public"."Product" ADD COLUMN     "imageUrl" TEXT;
